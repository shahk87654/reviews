const { MongoClient } = require('mongodb');

let client;
let clientPromise;

const uri = process.env.MONGO_URI;
if (!uri) throw new Error('Missing MONGO_URI env variable');

async function getClient() {
  if (!client) {
    client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    clientPromise = client.connect();
  }
  await clientPromise;
  return client;
}

module.exports = { getClient };
