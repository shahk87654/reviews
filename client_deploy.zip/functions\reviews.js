const { getClient } = require('./mongoClient');

exports.handler = async function(event, context) {
  const client = await getClient();
  const db = client.db('aramco_review');
  const reviews = db.collection('reviews');

  if (event.httpMethod === 'GET') {
    const docs = await reviews.find({}).limit(50).toArray();
    return {
      statusCode: 200,
      body: JSON.stringify(docs),
    };
  }

  if (event.httpMethod === 'POST') {
    try {
      const body = JSON.parse(event.body);
      const res = await reviews.insertOne(body);
      return {
        statusCode: 201,
        body: JSON.stringify({ insertedId: res.insertedId }),
      };
    } catch (err) {
      return { statusCode: 500, body: String(err) };
    }
  }

  return { statusCode: 405, body: 'Method Not Allowed' };
};
